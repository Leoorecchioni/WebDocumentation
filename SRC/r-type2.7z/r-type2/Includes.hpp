#define BOOST_BIND_GLOBAL_PLACEHOLDERS

#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <bits/stdc++.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <iostream>
#include <ostream>
#include <boost/asio.hpp>
#include <boost/bind.hpp>
#include <chrono>
#include <thread>
#include <future>
#include <string>
#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <queue>
#include <mutex>


using namespace boost::asio;
