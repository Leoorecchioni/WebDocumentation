
#ifndef GAME_HPP__
#define GAME_HPP__

#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <SFML/System.hpp>
#include <vector>
#include "GameElement.hpp"
#include "macro.hpp"
#include <iostream>

class Projectile {
    public:
        Projectile(const sf::Texture& texture, const sf::Vector2f& position, const sf::Vector2f& scale)
            : texture(texture), sprite(texture), velocity(1.0f, 0.0f) {
            sprite.setPosition(position.x + 120, position.y + 30);
            sprite.setScale(scale);
        }
        int get_pos_x()
        {
            return sprite.getPosition().x;
        }
        int get_pos_y()
        {
            return sprite.getPosition().y;
        }
        sf::Texture texture;
        sf::Sprite sprite;
        sf::Vector2f velocity;
    private:
};

class Enemy {
    public:
        Enemy(const sf::Texture& texture, const sf::Vector2f& position, const sf::Vector2f& scale)
            : texture(texture), sprite(texture), velocity(1.0f, 0.0f) {
            sprite.setPosition(windowWidth, position.y);
            sprite.setScale(scale);
        }
        int mob();

        void update() {
            sprite.move(-enemySpeed, 0);
        }

        void draw(sf::RenderWindow& window) {
            window.draw(sprite);
        }
        int get_pos_x()
        {
            return sprite.getPosition().x;
        }
        int get_pos_y()
        {
            return sprite.getPosition().y;
        }
        sf::Sprite sprite;
        sf::Texture texture;
        sf::Vector2f velocity;
        static constexpr float enemySpeed = 1.0f;
        static constexpr int windowWidth = 2100;
    private:
        
};

class IGame
{
    private:
    public:
        virtual ~IGame(void) = default;
        virtual int update(void) = 0;
        virtual int draw(void) = 0;
        virtual int display(void) = 0;
        virtual int clear(sf::Color) = 0;
        virtual int clear(void) = 0;
        virtual int input(void) = 0;
        virtual bool isOpen(void) = 0;
        virtual void close(void) = 0;
        virtual std::vector<sf::Keyboard::Key> getKeyPress(void) = 0;
        virtual std::vector<bool> getMouseClick(void) = 0;
        virtual sf::Vector2f getMousePosition(void) = 0;
        virtual int getMouseHoverElementId(void) = 0;
        virtual int addElement(Element *) = 0;
        virtual void deleteElement(int) = 0;
};


class Game : public IGame
{
    public:
        Game(void);
        Game(std::vector<Element *>);
        ~Game(void) {};
        int update(void);
        int draw(void);
        int display(void);
        int clear(sf::Color);
        int clear(void);
        int input(void);
        std::vector<sf::Keyboard::Key> getKeyPress(void);
        sf::Vector2f getMousePosition(void);
        std::vector<bool> getMouseClick(void);
        bool isOpen(void);
        void close(void);
        int getMouseHoverElementId(void);
        int addElement(Element *);
        int addElement(std::vector<Element *>);
        void deleteElement(int);
        void initSprites(void);
        void handleMovement();
        void playerKilled();
        void enemiKilled();
        void enemiKilled2();

    private:
        sf::RenderWindow window;
        std::vector<Element *> elements;
        std::vector<sf::Keyboard::Key> keyPress;
        std::vector<bool> mouseClick;
        Element mousElement;
        sf::Texture backgroundTexture;
        sf::Texture backgroundTexture2;
        sf::Sprite backgroundSprite;
        sf::Sprite backgroundSprite2;
        float backgroundX = 0.0f;
        float backgroundSpeed = 0.5f;
        float backgroundX2 = 1920.0f;
        std::vector<Projectile> projectiles;
        std::vector<Projectile> projectiles2;
        sf::Texture newProjectileTexture;
        sf::Texture newProjectileTexture2;
        sf::Texture texturePlayer;
        sf::Sprite spritePlayer;
        float playerSpeed = 0.4f;
        bool isMoving = false;
        std::vector<sf::IntRect> frames;
        int currentFrameIndex = 0;
        sf::Clock clock;
        sf::Clock shootingClock;
        float shootingInterval = 0.1f;
        sf::Clock shootingClock2;
        float shootingInterval2 = 1.5f;
        std::vector<Enemy> enemies;
        sf::Clock enemySpawnClock;
        sf::Time enemySpawnInterval = sf::seconds(2.0f);
        sf::Texture textureMob;
        sf::Sprite spriteMob;
};

int loop_game(void);
void removeElement(Game *game);
void setElement(sf::Vector2f position, sf::Vector2f scale,
                sf::Texture texture , int height, int width, int id, Element *element);
std::vector<Element *> element_base(void);
void createRandom(Game *game, int *id);

#endif
