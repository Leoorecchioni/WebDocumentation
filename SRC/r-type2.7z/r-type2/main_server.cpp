#include "./Includes.hpp"
#include "./UDPServer/UDPServer.hpp"

int main()
{
    UDPServer myServer;

    myServer.start_server();
    return 0;
}