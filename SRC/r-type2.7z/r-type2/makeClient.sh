#!/bin/bash
rm -f Client
g++ main_client.cpp UDPClient/UDPClient.cpp motor.cpp Game.cpp -o Client -lboost_system -lboost_thread -pthread -lsfml-graphics -lsfml-window -lsfml-system -lsfml-network
./Client