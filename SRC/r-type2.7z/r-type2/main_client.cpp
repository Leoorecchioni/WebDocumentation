#include "./Includes.hpp"
#include "./UDPClient/UDPClient.hpp"
#include "Game.hpp"

int main()
{
    UDPClient myClient;
    // loop_game();
    myClient.start_client();
    return 0;
}