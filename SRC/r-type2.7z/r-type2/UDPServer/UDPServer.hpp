#include "../Includes.hpp"

#ifndef UDPSERVER_HPP_
#define UDPSERVER_HPP_

struct dataToSend {
    int id = 0;
    int pos_x = 10;
    int pos_y = 10;
};

struct receivedData {
    int command = 0;
};

// Structure pour enregister la dernière commande envoyée
struct lastCommand {
    std::string player_ip = "";
    int command = 0;
};

class UDPServer {
    public:
        // Méthodes de la classe
        UDPServer();

        void send_number_to_client(std::vector<struct dataToSend>);
        void handle_queue(std::shared_ptr<receivedData> received_data, std::string client_ip);
        void receive_number_from_client();
        void initiate_receive_thread();
        void launch_game();
        int start_server();

        // Variables de la classe
    private:
        std::array<char, 1024> message_buffer;
        std::vector<dataToSend> entities;
        std::vector<std::string> players_list;
        bool emptyServer;

        // Créer une queue pour gérer plusieurs clients
        std::queue<std::shared_ptr<lastCommand>> data_queue;
        std::mutex queue_mutex;
};

#endif /* UDPSERVER_HPP_ */
