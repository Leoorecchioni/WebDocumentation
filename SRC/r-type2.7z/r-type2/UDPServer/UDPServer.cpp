#include "./UDPServer.hpp"

io_context server_context;

// Setup du Serveur
ip::udp::endpoint server_endpoint(ip::udp::v4(), 3945);
ip::udp::socket server_socket(server_context, server_endpoint);
ip::udp::endpoint sender_endpoint;

UDPServer::UDPServer()
{
    emptyServer = false;
    players_list.push_back("0.0.0.0");
    players_list.push_back("0.0.0.0");
    players_list.push_back("0.0.0.0");
    players_list.push_back("0.0.0.0");
}

// Envoyer des messages aux clients
void UDPServer::send_number_to_client(std::vector<struct dataToSend> data_to_send)
{
    // Envoyer le vecteur de structures aux clients
    server_socket.async_send_to(boost::asio::buffer(data_to_send.data(), data_to_send.size() * sizeof(dataToSend)), sender_endpoint,
       [this](const boost::system::error_code& error_send, std::size_t bytes_received) {
           if (error_send) {
                std::cerr << "Error sending message : " << error_send.message() << std::endl;
            }
       }
    );
}

// Gérer la queue pour les messages
void UDPServer::handle_queue(std::shared_ptr<receivedData> received_data, std::string client_ip)
{
    std::shared_ptr<struct lastCommand> last_command = std::make_shared<struct lastCommand>();

    int count = 0;
    int index = 0;

    last_command->player_ip = client_ip;
    last_command->command = received_data->command;

    // Verrouiller la queue avec un mutex
    {
        std::lock_guard<std::mutex> lock(queue_mutex);
        data_queue.push(last_command);
    }

    // Vérifier la liste des clients avant d'en ajouter un
    for (std::string index : players_list) {
        if (strcmp(client_ip.c_str(), index.c_str()) == 0) {
            count = count + 1;
        }
    }

    // Ajouter le nouveau client à la liste
    if (count == 0) {
        std::cout << "New player detected. Here is his IP: " << client_ip << std::endl;
        while (index != players_list.size()) {
            if (strcmp(players_list[index].c_str(), "0.0.0.0") == 0) {
                players_list[index] = client_ip;
                break;
            }
            index = index + 1;
        }
        emptyServer = true;
    }

    // Afficher les données extraites de la queue
    // std::cout << "Received message from " << client_ip << ": " << std::endl;
    // if (received_data) {
    //     std::cout << "Player's command: " << received_data->command << std::endl;
    //     std::cout << "--------------------" << std::endl;
    // }
}

// Recevoir des messages des clients
void UDPServer::receive_number_from_client()
{
    // Créer un pointeur pour stocker les données du client
    std::shared_ptr<struct receivedData> received_data = std::make_shared<struct receivedData>();

    server_socket.async_receive_from(boost::asio::buffer(received_data.get(), sizeof(struct receivedData)), sender_endpoint,
        [this, received_data](const boost::system::error_code& error_code, std::size_t bytes_received) {
            // Handler pour recevoir les messages ici
            if (!error_code) {
                std::string clientIP = sender_endpoint.address().to_string();

                // Ajouter les données dans la queue et les afficher
                handle_queue(received_data, clientIP);

                // Continuer de recevoir les messages
                receive_number_from_client();

            } else {
                std::cerr << "Error receiving message: " << error_code.message() << std::endl;
            }
        }
    );
}

// Lancer le jeu
void UDPServer::launch_game()
{
    // Stocker les données du client
    struct lastCommand last_command;

    dataToSend first_player;
    dataToSend second_player;

    int player_position = 0;
    int saved_position;

    int player1_posx = 10;
    int player1_posy = 10;

    int player2_posx = 10;
    int player2_posy = 10;

    while (1) {
        // std::cout << "je suis ici" << std::endl;
        if (emptyServer == true) {
            // Extraire la dernière commande de la queue
            {
                std::lock_guard<std::mutex> lock(queue_mutex);
                if (!data_queue.empty()) {
                    last_command = *data_queue.front();
                    data_queue.pop();
                }
            }

            // Vérifier quel joueur a envoyé la commande
            for (std::string index : players_list) {
                if (strcmp(index.c_str(), last_command.player_ip.c_str()) == 0) {
                    saved_position = player_position;
                }
                player_position = player_position + 1;
            }
            player_position = 0;

            // Modifier la position du premier joueur
            if (saved_position == 0) {
                if (last_command.command == 1) {
                    player1_posx -= 15;
                    first_player.pos_x = player1_posx;
                } else if (last_command.command == 2) {
                    player1_posx += 15;
                    first_player.pos_x = player1_posx;
                } else if (last_command.command == 3) {
                    player1_posy -= 15;
                    first_player.pos_y = player1_posy;
                } else if (last_command.command == 4) {
                    player1_posy += 15;
                    first_player.pos_y = player1_posy;
                }
            }
            
            // Modfier la position du deuxième joueur
            if (saved_position == 1) {
                if (last_command.command == 1) {
                    player2_posx -= 15;
                    second_player.pos_x = player2_posx;
                } else if (last_command.command == 2) {
                    player2_posx += 15;
                    second_player.pos_x = player2_posx;
                } else if (last_command.command == 3) {
                    player2_posy -= 15;
                    second_player.pos_y = player2_posy;
                } else if (last_command.command == 4) {
                    player2_posy += 15;
                    second_player.pos_y = player2_posy;
                }
            }

            first_player.id = 1;
            second_player.id = 1;

            entities.push_back(first_player);
            entities.push_back(second_player);
            // std::cout << "pos_x joueur 1 : " << first_player.pos_x << std::endl;

            send_number_to_client(entities);

            // Vider le vecteur de structures
            entities.clear();
            std::this_thread::sleep_for(std::chrono::milliseconds(16));
        }
    }
}

// Initialiser le thread d'écoute
void UDPServer::initiate_receive_thread()
{
    std::cout << "Starting listening thread..." << std::endl;

    receive_number_from_client();
    server_context.run();
}

// Lancer le serveur
int UDPServer::start_server()
{
    std::thread receive_thread(&UDPServer::initiate_receive_thread, this);
    // Lancer la boucle de jeu
    launch_game();

    receive_thread.join();
    return (0);
}
