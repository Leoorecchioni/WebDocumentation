#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <SFML/System.hpp>

sf::Sprite createSprite(const sf::Texture& texture, const sf::Vector2f& position, const sf::IntRect& textureRect, const sf::Vector2f& scale) {
    sf::Sprite sprite;
    sprite.setTexture(texture);
    sprite.setTextureRect(textureRect);
    sprite.setPosition(position);
    sprite.setScale(scale);
    return sprite;
}