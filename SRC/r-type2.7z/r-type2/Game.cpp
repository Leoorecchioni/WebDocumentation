#include "Game.hpp"
#include "Game2.hpp"

void Game::playerKilled()
{
    for (auto& enemy : enemies) {
        if (spritePlayer.getPosition().x < enemy.get_pos_x() + 130 &&
        spritePlayer.getPosition().x > enemy.get_pos_x() - 100 &&
        spritePlayer.getPosition().y < enemy.get_pos_y() + 50 &&
        spritePlayer.getPosition().y > enemy.get_pos_y() - 60)
            exit(84);
    }
}

void Game::enemiKilled() {
    for (int i = 0; i < enemies.size(); ++i) {
        for (int j = 0; j < projectiles.size(); ++j) {
            auto& enemy = enemies[i];
            auto& projectile = projectiles[j];
            if (projectile.get_pos_x() < enemy.get_pos_x() + 130 &&
                projectile.get_pos_x() > enemy.get_pos_x() - 100 &&
                projectile.get_pos_y() < enemy.get_pos_y() + 50 &&
                projectile.get_pos_y() > enemy.get_pos_y() - 60)
                enemies.erase(enemies.begin() + i);
                // projectile.sprite.setPosition(2000, 1200);
                // projectiles.erase(projectiles.begin() + i);
        }
    }
}

void Game::enemiKilled2() {
    for (int i = 0; i < enemies.size(); ++i) {
        for (int j = 0; j < projectiles2.size(); ++j) {
            auto& enemy = enemies[i];
            auto& projectile = projectiles2[j];
            if (projectile.get_pos_x() < enemy.get_pos_x() + 130 &&
                projectile.get_pos_x() > enemy.get_pos_x() - 100 &&
                projectile.get_pos_y() < enemy.get_pos_y() + 50 &&
                projectile.get_pos_y() > enemy.get_pos_y() - 60)
                enemies.erase(enemies.begin() + i);
                // projectile.sprite.setPosition(2000, 1200);
                // projectiles.erase(projectiles.begin() + i);
        }
    }
}

void Game::handleMovement() {
    bool moveLeft = false;
    bool moveRight = false;
    bool moveUp = false;
    bool moveDown = false;
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left)) {
        moveLeft = true;
        moveRight = false;
    } else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right)) {
        moveLeft = false;
        moveRight = true;
    }
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up)) {
        moveUp = true;
        moveDown = false;
    } else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Down)) {
        moveUp = false;
        moveDown = true;
    }
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::Space)) {
        if (shootingClock.getElapsedTime().asSeconds() >= shootingInterval) {
            Projectile newProjectile(newProjectileTexture, spritePlayer.getPosition(), sf::Vector2f(3.0f, 3.0f));
            projectiles.push_back(newProjectile);
            shootingClock.restart();
        }
    }
    for (auto it = projectiles.begin(); it != projectiles.end(); it += 1) {
        it->sprite.move(it->velocity);
        if (it->sprite.getPosition().x > window.getSize().x) {
            it = projectiles.erase(it);
            it -= 1;
        }
    }
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::E)) {
        if (shootingClock2.getElapsedTime().asSeconds() >= shootingInterval2) {
            Projectile newProjectile_2(newProjectileTexture2, spritePlayer.getPosition(), sf::Vector2f(2.5f, 2.5f));
            projectiles2.push_back(newProjectile_2);
            shootingClock2.restart();
        }
    }
    for (auto it = projectiles2.begin(); it != projectiles2.end(); it += 1) {
        it->sprite.move(it->velocity);
        if (it->sprite.getPosition().x > window.getSize().x) {
            it = projectiles2.erase(it);
            it -= 1;
        }
    }
    if (enemySpawnClock.getElapsedTime() >= enemySpawnInterval) {
        float yPos = static_cast<float>(std::rand() % window.getSize().y);
        Enemy newEnemy(textureMob, sf::Vector2f(1.0f, yPos), sf::Vector2f(3.0f, 3.0f));
        enemies.push_back(newEnemy);
        enemySpawnClock.restart();
    }
    if (moveLeft)
        spritePlayer.move(-playerSpeed, 0);
    if (moveRight)
        spritePlayer.move(playerSpeed, 0);
    if (moveUp)
        spritePlayer.move(0, -playerSpeed);
    if (moveDown)
        spritePlayer.move(0, playerSpeed);
}

int Game::draw()
{
    this->backgroundSprite = createSprite(backgroundTexture, sf::Vector2f(0, 0), sf::IntRect(0, 0, 1920, 1080), sf::Vector2f(1.0f, 1.0f));
    this->backgroundSprite2 = createSprite(backgroundTexture2, sf::Vector2f(0, 0), sf::IntRect(0, 0, 1920, 1080), sf::Vector2f(1.0f, 1.0f));
    backgroundX -= backgroundSpeed;
    backgroundX2 -= backgroundSpeed;
    if (backgroundX <= -1920)
        backgroundX = 1920;
    if (backgroundX2 <= -1920)
        backgroundX2 = 1920;
    handleMovement();
    
    this->backgroundSprite.setPosition(backgroundX, 0);
    this->backgroundSprite2.setPosition(backgroundX2, 0);
    this->window.draw(this->backgroundSprite);
    this->window.draw(this->backgroundSprite2);
    
    this->window.draw(this->spritePlayer);
    // for (auto cursor : this->elements)
    //     this->window.draw(cursor->sprite);
    this->window.draw(this->mousElement.sprite);
    for (int i = 0; i < 5; i++) {
        frames.push_back(sf::IntRect(i * 33, 0, 33, 19));
    }
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up) ||
        sf::Keyboard::isKeyPressed(sf::Keyboard::Down)) {
        isMoving = true;
    } else {
        isMoving = false;
        spritePlayer.setTextureRect(frames[0]);
    }

    if (isMoving && clock.getElapsedTime().asMilliseconds() > 150) {
        currentFrameIndex = (currentFrameIndex + 1) % frames.size();
        spritePlayer.setTextureRect(frames[currentFrameIndex]);
        clock.restart();
    }
    for (const auto& projectile : projectiles) {
        window.draw(projectile.sprite);
    }
    for (const auto& projectile : projectiles2) {
        window.draw(projectile.sprite);
    }
    for (auto& enemy : enemies) {
        enemy.update();
        window.draw(enemy.sprite);
    }
    return 0;
}

int Game::display()
{
    this->window.display();
    return 0;
}

int Game::clear(sf::Color color)
{
    this->window.clear(color);
    return 0;
}

int Game::clear()
{
    this->window.clear();
    return 0;
}

bool touch(Element first, Element second)
{
    return (
        first.position.x + first.scale.x * first.width >=
        second.position.x &&
        first.position.x <=
        second.position.x + second.scale.x * second.width
        &&
        first.position.y + first.scale.y * first.height >=
        second.position.y &&
        first.position.y <=
        second.position.y + second.scale.y * second.height
        );
}

int Game::getMouseHoverElementId()
{
    int id = -1;
    sf::Vector2f mousePosition = this->getMousePosition();

    for (auto element : this->elements) {
        if (touch(this->mousElement, *element))
            id = element->id;
    }
    return id;
}



int Game::addElement(Element *element)
{
    this->elements.push_back(element);
    return 0;
}


int Game::addElement(std::vector<Element *> list)
{
    for (auto &cursor : list)
        this->elements.push_back(cursor);
    return 0;
}

int Game::input()
{
    return 0;
}

int Game::update()
{
    sf::Event event;

    std::vector<sf::Keyboard::Key> newKeyPress;

    while (this->window.pollEvent(event)) {
        if (event.type == sf::Event::KeyPressed)
            newKeyPress.push_back(event.key.code);
        if (event.type == sf::Event::Closed) {
            this->window.close();
            exit(0);
        }
    }
    this->keyPress = newKeyPress;
    this->mousElement.position = (sf::Vector2f) sf::Mouse::getPosition(this->window);
    this->mousElement.sprite.setPosition(this->mousElement.position);
    this->mouseClick[0] = sf::Mouse::isButtonPressed(sf::Mouse::Left);
    this->mouseClick[1] = sf::Mouse::isButtonPressed(sf::Mouse::Right);
    return 0;
}

void Game::deleteElement(int id)
{
    if (this->elements.size() < 1) return;
    for (int i = 0; this->elements.size() > i; i++) {
        if (this->elements[i]->id == id) {
            std::vector<Element *> newList;
            for (int nb = 0; this->elements.size() > nb; nb++) {
                if (nb == i) continue;
                newList.push_back(elements[nb]);
            }
            this->elements = newList;
            this->deleteElement(id);
            return;
        }
    }
}

///                 CONSTRUCTOR



Game::Game(void) {

    this->window.create(sf::VideoMode(SCREEN_W, SCREEN_H), TITLE);
    this->window.setMouseCursorVisible(false);

    this->mousElement.height = MOUSE_H;
    this->mousElement.width = MOUSE_W;
    this->mousElement.texture.loadFromFile(MOUSE_TEXTURE);
    this->mousElement.sprite.setTexture(this->mousElement.texture);
    this->mousElement.scale = sf::Vector2f(1, 1);
    this->mousElement.id = 0;

    this->mouseClick.push_back(false);
    this->mouseClick.push_back(false);

}

void Game::initSprites()
{
    std::string backgroundImagePath = "./assets/sprite/etoile2.jpg";
    std::string backgroundImagePath2 = "./assets/sprite/etoile3.jpg";
    std::string stringPlayer = "./assets/sprite/voiture.png";
    std::string newProjectileImagePath = "./assets/sprite/missile.png";
    std::string specialBulletPath = "./assets/sprite/spell.png";
    std::string pathMob = "./assets/sprite/mob.png";
    if (!backgroundTexture.loadFromFile(backgroundImagePath)) {
        std::cerr << "Erreur de chargement de la texture du fond depuis : " << backgroundImagePath << std::endl;
        exit(84);
    }
    if (!backgroundTexture2.loadFromFile(backgroundImagePath2)) {
        std::cerr << "Erreur de chargement de la texture du fond depuis : " << backgroundImagePath2 << std::endl;
        exit(84);
    }
    if (!texturePlayer.loadFromFile(stringPlayer)) {
        std::cerr << "Erreur de chargement de la texture du fond depuis : " << stringPlayer << std::endl;
        exit(84);
    }
    if (!newProjectileTexture.loadFromFile(newProjectileImagePath)) {
        std::cerr << "Erreur de chargement de la nouvelle texture du projectile depuis : " << newProjectileImagePath << std::endl;
        exit(84);
    }
    if (!newProjectileTexture2.loadFromFile(specialBulletPath)) {
        std::cerr << "Erreur de chargement de la nouvelle texture du projectile depuis : " << specialBulletPath << std::endl;
        exit(84);
    }
    if (!textureMob.loadFromFile(pathMob)) {
        std::cerr << "Erreur de chargement de la nouvelle texture du projectile depuis : " << pathMob << std::endl;
        exit(84);
    }
    std::cout << "salam" << std::endl;
}


Game::Game(std::vector<Element*> list)
{
    this->window.create(sf::VideoMode(SCREEN_W, SCREEN_H), TITLE);
    this->window.setMouseCursorVisible(false);
    sf::IntRect textureRect(0, 0, 33, 19);
    sf::Vector2f scale(4.0f, 4.0f);
    for (auto &cursor : list)
        this->elements.push_back(cursor);
    this->mousElement.height = MOUSE_H;
    this->mousElement.width = MOUSE_W;
    this->mousElement.texture.loadFromFile(MOUSE_TEXTURE);
    this->mousElement.sprite.setTexture(this->mousElement.texture);
    this->mousElement.id = 0;
    this->mouseClick.push_back(false);
    this->mouseClick.push_back(false);
    initSprites();

    this->spritePlayer = createSprite(texturePlayer, sf::Vector2f(250, 450), textureRect, scale);

    // handleMovement();
    
}
///                         ACCESSOR

bool Game::isOpen() { return this->window.isOpen(); }
void Game::close() { this->window.close(); }

std::vector<sf::Keyboard::Key> Game::getKeyPress() { return this->keyPress; }

sf::Vector2f Game::getMousePosition(void) { return this->mousElement.position; }
std::vector<bool> Game::getMouseClick(void) { return this->mouseClick; }
