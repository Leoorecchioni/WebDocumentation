#include "Game.hpp"
#include "macro.hpp"
#include <random>

void setElement(sf::Vector2f position, sf::Vector2f scale,
                sf::Texture texture , int height, int width, int id, Element *element)
{
    element->position = position;
    element->scale = scale;
    element->texture = texture;
    element->sprite.setTexture(element->texture);
    element->sprite.setScale(element->scale);
    element->sprite.setPosition(element->position);
    element->height = height;
    element->width = width;

    element->id = id;
}

std::vector<Element *> element_base(void)
{
    std::vector<Element *> list_element;
    Element *element = new (Element);

    sf::Vector2f position = sf::Vector2f(30, 2);
    sf::Vector2f scale = sf::Vector2f(0.5, 0.5);
    sf::Texture texture; texture.loadFromFile(PLAYER_TEXTURE);

    setElement(position, scale, texture, PLAYER_SIZE, PLAYER_SIZE, 1,element);

    list_element.push_back(element);

    position = sf::Vector2f(170, 50);
    scale = sf::Vector2f(0.35, 0.35);
    element = new (Element);
    setElement(position, scale, texture, PLAYER_SIZE, PLAYER_SIZE, 2, element);

    list_element.push_back(element);

    return list_element;
}

void createRandom(Game *game, int *id)
{
    float randomFloat = 0.2 + ((float)rand() / RAND_MAX) * (1.0 - 0.2);
    int width = SCREEN_W + ((float)rand() / RAND_MAX) * (1 - SCREEN_W);
    int height = SCREEN_H + ((float)rand() / RAND_MAX) * (1 - SCREEN_H);
    Element *element = new (Element);
    sf::Vector2f scale = sf::Vector2f(randomFloat, randomFloat);
    sf::Vector2f position = sf::Vector2f(width, height);
    sf::Texture texture; texture.loadFromFile(PLAYER_TEXTURE);
    setElement(position, scale, texture, PLAYER_SIZE, PLAYER_SIZE, *id,  element);
    game->addElement(element);
    (*id)++;
}


void removeElement(Game *game)
{
    int id = game->getMouseHoverElementId();

    if (id < 1) return;
    game->deleteElement(id);
}

int loop_game()
{
    std::vector<Element *> list_element = element_base();

    int id = 3;
    std::vector<sf::Keyboard::Key> inputs;
    Game game(list_element);
    while (game.isOpen()) {
        game.clear(sf::Color::Blue);
        game.draw();
        game.update();
        game.handleMovement();
        game.playerKilled();
        game.enemiKilled();
        game.enemiKilled2();
        inputs = game.getKeyPress();

        for (auto key : inputs) {
            if (key == sf::Keyboard::Key::Escape)
                game.close();
            if (key == sf::Keyboard::Key::Enter)
                createRandom(&game, &id);
            if (key == sf::Keyboard::Key::Delete)
                removeElement(&game);
        }
        if (game.getMouseClick()[0])
            removeElement(&game);
        game.display();
    }
    return 0;
}
