#ifndef MACRO_HPP__
    #define MACRO_HPP__

    #define PLAYER_TEXTURE "./sprite/sprite.png"
    #define TITLE "r-type"
    #define SCREEN_H 1080
    #define SCREEN_W 1920

    #define PLAYER_SIZE 400

    #define MOUSE_H 51
    #define MOUSE_W 46
    #define MOUSE_TEXTURE "./sprite/cursor.png"

#endif