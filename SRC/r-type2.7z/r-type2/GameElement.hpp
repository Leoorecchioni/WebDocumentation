#ifndef GAMEELEMENT_HPP__
#define GAMEELEMENT_HPP__

#include <SFML/Graphics.hpp>

typedef struct Element_struct {
    sf::Sprite sprite;
    sf::Vector2f position;
    sf::Texture texture;
    sf::Vector2f scale;
    int width;
    int height;
    int id;
} Element;

class IGameElement
{
    public:
        ~IGameElement() = default;
        virtual sf::Sprite getSprite(void) = 0;
};

class Player : public IGameElement
{
    public:
        Player();
        ~Player();

        sf::Sprite getSprite(void) {return this->element.sprite;};
    private:
        Element element;
};

class Npc : public IGameElement
{
    public:
        Npc();
        ~Npc();

        sf::Sprite getSprite(void) {return this->element.sprite;};
    private:
        Element element;
};

#endif