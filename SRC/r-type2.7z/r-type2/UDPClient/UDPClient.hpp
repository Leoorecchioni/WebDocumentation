#include "../Includes.hpp"

#ifndef UDPCLIENT_HPP_
#define UDPCLIENT_HPP_

struct receivedData {
    int id = 0;
    int pos_x = 0;
    int pos_y = 0;
};

struct dataToSend {
    int command = 0;
};

class UDPClient {
    public:
        // Méthodes de la classe
        UDPClient();

        void handle_sent_messages(const boost::system::error_code& error_send, std::size_t bytes_received);
        void send_number_to_server(struct dataToSend& data_to_send);
        void handle_queue(std::shared_ptr<std::vector<receivedData>> received_data_pointer);
        void receive_number();
        void start_game();
        void initiate_network_thread();
        void get_ip_address();
        void start_client();
        void initSprites();

        // Variables de la classe
    private:
        int sent_number;
        std::array<char, 1024> message_buffer;
        int user_input_value;
        std::string ip_address;
        // Créer une queue pour stocker les données
        std::queue<std::shared_ptr<std::vector<receivedData>>> client_queue;
        std::mutex client_mutex;
        bool leftKeyPressed;
        bool rightKeyPressed;
        bool upKeyPressed;
        bool downKeyPressed;
        bool keyPressed;
        sf::Texture backgroundTexture;
        sf::Texture backgroundTexture2;
        sf::Sprite backgroundSprite;
        sf::Sprite backgroundSprite2;
        float backgroundX = 0.0f;
        float backgroundSpeed = 0.5f;
        float backgroundX2 = 1920.0f;
};

#endif /* UDPCLIENT_HPP_ */
