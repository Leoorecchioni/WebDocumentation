#include "./UDPClient.hpp"
#include "../Game.hpp"

io_context client_context;
sf::RenderWindow window(sf::VideoMode(1920, 1080), "SFML Client");
sf::Texture texture;
sf::Sprite sprite;

// Paramétrer le socket du client
// ip mathieu : 10.79.217.97
// ip léo 10.79.216.175
// ip gianni 10.79.216.130
ip::udp::endpoint server_endpoint(ip::make_address("127.0.0.1"), 3945);
ip::udp::socket client_socket(client_context);


/////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////
// void setElement(sf::Vector2f position, sf::Vector2f scale,
//                 sf::Texture texture , int height, int width, int id, Element *element)
// {
//     element->position = position;
//     element->scale = scale;
//     element->texture = texture;
//     element->sprite.setTexture(element->texture);
//     element->sprite.setScale(element->scale);
//     element->sprite.setPosition(element->position);
//     element->height = height;
//     element->width = width;

//     element->id = id;
// }

// std::vector<Element *> element_base(void)
// {
//     std::vector<Element *> list_element;
//     Element *element = new (Element);

//     sf::Vector2f position = sf::Vector2f(30, 2);
//     sf::Vector2f scale = sf::Vector2f(0.5, 0.5);
//     sf::Texture texture; texture.loadFromFile(PLAYER_TEXTURE);

//     setElement(position, scale, texture, PLAYER_SIZE, PLAYER_SIZE, 1,element);

//     list_element.push_back(element);

//     position = sf::Vector2f(170, 50);
//     scale = sf::Vector2f(0.35, 0.35);
//     element = new (Element);
//     setElement(position, scale, texture, PLAYER_SIZE, PLAYER_SIZE, 2, element);

//     list_element.push_back(element);

//     return list_element;
// }

// void createRandom(Game *game, int *id)
// {
//     float randomFloat = 0.2 + ((float)rand() / RAND_MAX) * (1.0 - 0.2);
//     int width = SCREEN_W + ((float)rand() / RAND_MAX) * (1 - SCREEN_W);
//     int height = SCREEN_H + ((float)rand() / RAND_MAX) * (1 - SCREEN_H);
//     Element *element = new (Element);
//     sf::Vector2f scale = sf::Vector2f(randomFloat, randomFloat);
//     sf::Vector2f position = sf::Vector2f(width, height);
//     sf::Texture texture; texture.loadFromFile(PLAYER_TEXTURE);
//     setElement(position, scale, texture, PLAYER_SIZE, PLAYER_SIZE, *id,  element);
//     game->addElement(element);
//     (*id)++;
// }


// void removeElement(Game *game)
// {
//     int id = game->getMouseHoverElementId();

//     if (id < 1) return;
//     game->deleteElement(id);
// }
/////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////

UDPClient::UDPClient()
{
    sent_number = 1;
    keyPressed = true;
}

// Gérer l'envoi de nombres au serveur
void UDPClient::handle_sent_messages(const boost::system::error_code& error_send, std::size_t bytes_received)
{
    if (!error_send) {
        // std::cout << "Number successfully sent." << std::endl;
    } else {
        std::cerr << "Erreur d'envoi: " << error_send.message() << std::endl;
    }
}

void UDPClient::send_number_to_server(struct dataToSend& data_to_send)
{
    // Envoi des données au serveur
    client_socket.async_send_to(boost::asio::buffer(&data_to_send, sizeof(data_to_send)), server_endpoint,
        [this](const boost::system::error_code& error_send, std::size_t bytes_sent) {
            this->handle_sent_messages(error_send, bytes_sent);
        }
    );
}

void UDPClient::handle_queue(std::shared_ptr<std::vector<receivedData>> received_data_pointer)
{
    // Verrouiller l'accès à la queue et y stocker la réponse du serveur
    {
        std::lock_guard<std::mutex> lock(client_mutex);
        client_queue.push(received_data_pointer);
    }
}

void UDPClient::receive_number()
{   
    // Créer un pointeur pour recevoir les données du serveur
    std::shared_ptr<std::vector<struct receivedData>> received_data_pointer = std::make_shared<std::vector<struct receivedData>>(2);

    client_socket.async_receive_from(boost::asio::buffer(received_data_pointer->data(), received_data_pointer->size() * sizeof(receivedData)), server_endpoint,
        [this, received_data_pointer](const boost::system::error_code& error_received, std::size_t bytes_received) {
            if (!error_received) {
                // Parcourir le vecteur de structures et afficher leur contenu
                handle_queue(received_data_pointer);

                // Continuer à recevoir des messages
                receive_number();
            } else {
                std::cerr << "Error receiving message: " << error_received.message() << std::endl;
            }
        }
    );
}



void UDPClient::start_game()
{
    struct dataToSend data_to_send;
    // std::vector<Element *> list_element = element_base();
    // Game game(list_element);
    // std::vector<sf::Keyboard::Key> inputs;
    // int id = 3;

    std::vector<receivedData> received_vector;
    struct receivedData received_data;

    // Créer un vecteur de sprites
    std::vector<sf::Sprite> spritesVector;
    sf::Texture texture;
    if (!texture.loadFromFile("../assets/sprite/a.png")) {
        std::cerr << "Could not load texture." << std::endl;
        exit (84);
    }

    int index = 0;
    int saved_index = 0;

    while (window.isOpen()) {
        
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed) {
                window.close();
            } else if (event.type == sf::Event::KeyPressed && event.key.code == sf::Keyboard::Return) {
                data_to_send.command = 5;
            }
        }

        // Vérifiez l'état de la touche Flèche Gauche
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left)) {
            if (!leftKeyPressed) {
                leftKeyPressed = true;
                keyPressed = true;
                data_to_send.command = 1;
            }
        } else {
            leftKeyPressed = false;
        }

        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right)) {
            if (!rightKeyPressed) {
                rightKeyPressed = true;
                keyPressed = true;
                data_to_send.command = 2;
            }
        } else {
            rightKeyPressed = false;
        }

        // Vérifiez l'état de la touche Flèche Haut
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up)) {
            if (!upKeyPressed) {
                keyPressed = true;
                upKeyPressed = true;
                data_to_send.command = 3;
            }
        } else {
            upKeyPressed = false;
        }
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Down)) {
            if (!downKeyPressed) {
                keyPressed = true;
                downKeyPressed = true;
                data_to_send.command = 4;
            }
        } else {
            downKeyPressed = false;
        }

        // Extraire le dernier élément de la queue
        {
            std::lock_guard<std::mutex> lock(client_mutex);
            if (!client_queue.empty()) {
                received_vector = *client_queue.front();
                client_queue.pop();
            }
        }

        // Initialiser tous les sprites dans un vecteur
        if (!received_vector.empty()) {
            spritesVector.clear();
            
            for (auto& index : received_vector) {
                if (index.id != 0) {
                    sf::Sprite sprite(texture);
                    sprite.setPosition(index.pos_x, index.pos_y);
                    spritesVector.push_back(sprite);
                }
            }
        }

        // Envoyer la commande au serveur
        if (keyPressed == true) {
            // if (data_to_send.command != 0)
            //     std::cout << data_to_send.command << std::endl;
            send_number_to_server(data_to_send);
        }
        // data_to_send.command = 4;
        data_to_send.command = 0;

        keyPressed == false;
        rightKeyPressed = false;
        leftKeyPressed = false;
        upKeyPressed = false;
        downKeyPressed = false;

        window.clear();
        // std::cout << "size : " << spritesVector.size() << std::endl;
        for (const sf::Sprite& sprite : spritesVector) {
            window.draw(sprite);
        }
        window.display();

        // Envoyer les données 60 fois par seconde
        std::this_thread::sleep_for(std::chrono::milliseconds(16));
    }
}

// Initialisation du thread
void UDPClient::initiate_network_thread()
{
    std::cout << "Bienvenue dans le thread !" << std::endl;
    receive_number();
    client_context.run();
}

void UDPClient::get_ip_address()
{
    io_context io_context;
    ip::tcp::resolver resolver(io_context);
    ip::tcp::resolver::query query(boost::asio::ip::host_name(), "");

    ip::tcp::resolver::iterator endpoints = resolver.resolve(query);
    ip::tcp::resolver::iterator end;

    while (endpoints != end) {
        ip::tcp::endpoint endpoint = *endpoints;
        if (endpoint.protocol() == ip::tcp::v4()) {
            ip_address = endpoint.address().to_string();
        }
        endpoints++;
    }
}

void UDPClient::start_client()
{
    // Récupérer l'adresse IP du client
    get_ip_address();

    if (!client_socket.is_open()) {
        client_socket.open(ip::udp::v4());
    } else {
        std::cout << "Client socket already opened." << std::endl;
    }

    std::thread network_thread(&UDPClient::initiate_network_thread, this);
    start_game();
    network_thread.join();
}
