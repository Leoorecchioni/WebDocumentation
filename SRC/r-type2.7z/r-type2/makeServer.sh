#!/bin/sh

rm -f Server
g++ main_server.cpp UDPServer/UDPServer.cpp -o Server -lboost_system -lboost_thread -pthread -lsfml-graphics -lsfml-window -lsfml-system -lsfml-network
./Server